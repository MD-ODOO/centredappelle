/* === Executive Dashboard Styles === */
.exec-dashboard {
    padding: 30px;
    background: #f4f7fb;
    font-family: "Roboto", "Helvetica", sans-serif;
}

/* --- Period Filter --- */
.period-filter {
    margin-bottom: 20px;
}
.period-filter button {
    background: #1f2937;
    color: #fff;
    border: none;
    padding: 8px 16px;
    margin-right: 8px;
    border-radius: 6px;
    cursor: pointer;
    font-weight: 500;
    transition: background 0.2s ease;
}
.period-filter button:hover {
    background: #111827;
}

/* --- KPI Row --- */
.kpi-row {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    margin-top: 20px;
}
.kpi-card {
    flex: 1;
    min-width: 150px;
    padding: 25px;
    border-radius: 12px;
    color: white;
    text-align: center;
    font-weight: 600;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    transition: transform 0.2s ease;
}
.kpi-card:hover {
    transform: translateY(-2px);
}
.kpi-card.blue { background: #2563eb; }
.kpi-card.green { background: #16a34a; }
.kpi-card.red { background: #dc2626; }
.kpi-card.purple { background: #7c3aed; }

/* --- Tables --- */
.exec-table {
    width: 100%;
    margin-top: 25px;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    border-collapse: collapse;
    font-size: 14px;
}
.exec-table th {
    background: #1f2937;
    color: white;
    padding: 12px;
    text-align: left;
}
.exec-table td {
    padding: 12px;
    border-bottom: 1px solid #eee;
}
.exec-table tr:hover {
    background: #f3f4f6;
    cursor: pointer;
}

/* --- Badges --- */
.badge-green {
    background: #28a745;
    color: white;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
    display: inline-block;
    text-align: center;
}
.badge-red {
    background: #dc3545;
    color: white;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
    display: inline-block;
    text-align: center;
}
.badge-orange {
    background: #ff9800;
    color: white;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
    display: inline-block;
    text-align: center;
}

/* --- Sub Tables (for Conseillers inside Campaigns) --- */
.sub-row {
    background: #f9fafb;
}
.sub-table {
    width: 100%;
    font-size: 13px;
    border-collapse: collapse;
}
.sub-table th {
    background: #374151;
    color: white;
    padding: 8px;
    text-align: left;
}
.sub-table td {
    padding: 8px;
    border-bottom: 1px solid #e5e7eb;
}

/* --- Responsive --- */
@media (max-width: 768px) {
    .kpi-row {
        flex-direction: column;
    }
    .period-filter button {
        margin-bottom: 8px;
    }
}